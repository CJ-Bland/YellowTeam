
public class Album {

}
